# NovaHD TV

Android TV WebView wrapper for https://novahd.cc/

## Build
Open this folder in Android Studio and let Gradle sync.
Then choose Build > Build APK(s).

## Install on Android TV
Enable Developer Options / USB debugging on the TV, connect with ADB, then:
adb install -r app/build/outputs/apk/debug/app-debug.apk

## Notes
- The app is TV-launcher compatible via LEANBACK_LAUNCHER.
- It is landscape/fullscreen and designed for D-pad/Back navigation.
- Website behavior still depends on what novahd.cc allows and on the TV's WebView/Chromium version.
